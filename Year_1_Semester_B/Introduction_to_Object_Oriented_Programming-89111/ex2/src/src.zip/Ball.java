import biuoop.DrawSurface;
/**
 *
 * @author Omry
 *
 */
public class Ball {
    //Static vars to easy use for crashing
    public static final int RIGHT = 1;
    public static final int LEFT = 2;
    public static final int TOP = 3;
    public static final int BOTTOM = 4;
    /**
     * Class Ball.
     * members: center - Point center of the circle,
     *          radius - int, the radius of the circle,
     *          color - Color, the color of the circle,
     *          vel - Velocity, the velocity of the circle movement
     *          xStartFrame,yStartFrame,xEndFrame,yEndFrame
     * Constructor: 3 -with frame start and end, without frame start and end,
     *               with point of center or with coordinate of center (x,y)
     * Methods: getX, getY, getSize, drawOn, setVelocity(dx,dy),
     *          setVelocity(Velocity),getVelocity, crash, moveOneStep
     */
    private Point center;
    private int radius;
    private java.awt.Color color;
    private Velocity vel;
    private int xStartFrame;
    private int yStartFrame;
    private int xEndFrame;
    private int yEndFrame;

    /**
     * Constructor.
     * @param center - the center point of the ball
     * @param r - the radius of the ball
     * @param color - the color of the ball
     * @param frameXSize - the width of the screen
     * @param frameYSize - the height of the screen
     */
    public Ball(Point center, int r, java.awt.Color color, int frameXSize, int frameYSize) {
        this.center = center;
        this.radius = r;
        this.color = color;
        this.vel = new Velocity(0, 0);
        this.xStartFrame = 0;
        this.yStartFrame = 0;
        this.xEndFrame = frameXSize;
        this.yEndFrame = frameYSize;
    }

    /**
     * Constructor.
     * @param x - the x of the center of the ball
     * @param y - the y of the center of the ball
     * @param r - the radius of the ball
     * @param color - the color of the ball
     * @param frameXSize -  the width of the screen
     * @param frameYSize - the height of the screen
     */
    public Ball(int x, int y, int r, java.awt.Color color, int frameXSize, int frameYSize) {
        this(new Point(x, y), r, color, frameXSize, frameYSize);
    }

    /**
     * set the x coordinate of the ball.
     * @param xStartFrameSet - the x coordinate we want to set
     */
    public void setXStartFrame(int xStartFrameSet) {
        this.xStartFrame = xStartFrameSet;
    }

    /**
     * set the y coordinate of the ball.
     * @param yStartFrameSet - the y coordinate we want to set
     */
    public void setYStartFrame(int yStartFrameSet) {
        this.yStartFrame = yStartFrameSet;
    }

    /**
     * Return the x coordinate of the center of the ball.
     * @return the x coordinate of the center of the ball.
     */
    public int getX() {
        return (int) this.center.getX();
    }

    /**
     * Return the y coordinate of the center of the ball.
     * @return theyx coordinate of the center of the ball.
     */
    public int getY() {
        return (int) this.center.getY();
    }

    /**
     * Return size of the ball.
     * @return size of the ball
     */
    public int getSize() {
        return (int) (Math.PI * Math.pow(this.radius, 2));
    }

    /**
     * Draw the ball on the given surface.
     * @param surface - DrawSurface, the surface we want to draw on it
     */
    public void drawOn(DrawSurface surface) {
        //Set the color of the ball to be his color we set already
        surface.setColor(this.color);
        //Draw the fill circle (ball)
        surface.fillCircle((int) this.center.getX(), (int) this.center.getY(), this.radius);
    }

    /**
     * Set the velocity of the ball - by velocity.
     * @param v - Velocity, to be set
     */
    public void setVelocity(Velocity v) {
        this.vel = v;
    }

    /**
     * Set the velocity of the ball - by dx and dy.
     * @param dx - double, number of x unites to move
     * @param dy - double, number of y unites to move
     */
    public void setVelocity(double dx, double dy) {
        this.setVelocity((new Velocity(dx, dy)));
    }

    /**
     * Return the Velocity of the ball.
     * @return Velocity of the ball
     */
    public Velocity getVelocity() {
        return this.vel;
    }

    /**
     * Check if the ball crash in the frame.
     * @return Ball.RIGHT(1) - if the ball crash on the right
     *                          border of the frame and etc
     */
    public int crash() {
        if (this.center.getX() + this.radius > this.xEndFrame) {
            return Ball.RIGHT;
        }
        if (this.center.getX() - this.radius < xStartFrame) {
            return Ball.LEFT;
        }
        if (this.center.getY() + this.radius > this.yEndFrame) {
            return Ball.BOTTOM;
        }
        if (this.center.getY() - this.radius < yStartFrame) {
            return Ball.TOP;
        }
        return 0;
    }

    /**
     * Check if the ball crash and change the velocity according to the crash.
     * call the function applyToPoint to change the center point
     */
    public void moveOneStep() {
        int crash;
        //Check where the crash happened
        crash = this.crash();
        if (crash == Ball.RIGHT) {
            this.setVelocity(Math.abs(this.getVelocity().getDx()) * -1, this.getVelocity().getDy());
        } else if (crash == Ball.LEFT) {

            this.setVelocity(Math.abs(this.getVelocity().getDx()), this.getVelocity().getDy());
        } else if (crash == Ball.BOTTOM) {

            this.setVelocity(this.getVelocity().getDx(), Math.abs(this.getVelocity().getDy()) * -1);
        } else if (crash == Ball.TOP) {

            this.setVelocity(this.getVelocity().getDx(), Math.abs(this.getVelocity().getDy()));
        }
        this.center = this.getVelocity().applyToPoint(this.center);
    }
}
