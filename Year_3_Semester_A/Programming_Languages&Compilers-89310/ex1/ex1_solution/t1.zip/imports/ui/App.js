import React, { Component } from 'react';
import ReactDOM from 'react-dom';
 
// App component - represents the whole app
export default class App extends Component {
    handleSubmit(event) {
        event.preventDefault();
     
        // Find the text field via the React ref
        const firstname = ReactDOM.findDOMNode(this.refs.FirstnameInput).value.trim();
        const lastname = ReactDOM.findDOMNode(this.refs.LastnameInput).value.trim();
        const grade = ReactDOM.findDOMNode(this.refs.GradeInput).value.trim();
        var red  = document.getElementById('red');
        red.innerHTML = "";
        if (firstname == "" || lastname == "" || grade == "") {
          red.innerHTML = "You must fill all the fields!";
        } else {
          var output  = document.getElementById('output');

          var html = output.innerHTML;

          html = html.replace("</table>", '');

          var line = "<tr><td>" + firstname + "</td><td>" + lastname + "</td><td><b>" + grade + "</b></td></tr>";

          output.innerHTML = html +  line + "</table>";
        }

        // Clear form
        ReactDOM.findDOMNode(this.refs.FirstnameInput).value = '';
        ReactDOM.findDOMNode(this.refs.LastnameInput).value = '';
        ReactDOM.findDOMNode(this.refs.GradeInput).value = '';
      }

  render() {
    return (
      <div className="container">
        <header>
          <h1>Grade Form and Table</h1>
          <h5>Here every one can grade our work. Please give us 100!</h5>
          <font id="red" color="red"></font>
          <form className="new-grade" onSubmit={this.handleSubmit.bind(this)} >
            Firstname: <input type="text" ref="FirstnameInput" placeholder="Type here firstname"/><br/>
            Lastname: <input type="text" ref="LastnameInput" placeholder="Type here lastname"/><br/>
            Grade: <input type="text" ref="GradeInput" placeholder="Type here grade"/><br/>
            <input type="submit" value= "Submit!"/>
          </form>
        </header>
        <ul>
          <div id="output">
            <table>
              <tr>
                <th>Firstname</th>
                <th>Lastname</th>
                <th>Grade</th>
              </tr>
            </table>
          </div>
        </ul>
      </div>
    );
  }
}